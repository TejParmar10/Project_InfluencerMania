<?php

declare(strict_types=1);

namespace Phpml\Association;

use Phpml\Estimator;

interface Associator extends Estimator
{
}
